﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentMaintenance.Models
{
    public class MaintenanceCheckList
    {
        public int No { get; set; }
        public string Pro1 { get; set; }
        public string Pro2 { get; set; }
        public bool Pro3 { get; set; }
        public bool Pro4 { get; set; }
    }
}
