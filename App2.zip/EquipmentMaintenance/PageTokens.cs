﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentMaintenance
{
    public static class PageTokens
    {
        public const string EquipmentPage = "Equipment";
        public const string EquipmentDetailPage = "EquipmentDetail";
    }
}
