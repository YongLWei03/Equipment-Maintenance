﻿using Prism.Windows.Mvvm;
namespace EquipmentMaintenance.Views
{
    public sealed partial class EquipmentDetailPage : SessionStateAwarePage
    {
        public EquipmentDetailPage()
        {
            this.InitializeComponent();
        }
    }
}

